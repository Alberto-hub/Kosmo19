$(function () {
    $("#find").css('cursor', 'pointer');
    $('#find').click(function () {
        location.href = 'Find_ID2.html';
    });
});