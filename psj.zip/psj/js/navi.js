$(document).ready( function() {
	$("#header").load("header.html");
});