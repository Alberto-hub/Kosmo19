$(function () {
    $("#find").css('cursor', 'pointer');
    $('#gologin').click(function () {
        location.href = 'Login_Main.html';
    });
    $('#findpwd').click(function () {
        location.href = 'Find_PWD.html';
    });
});