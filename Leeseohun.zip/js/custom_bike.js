$(function() {
    $("#back").click(function(){
        history.back(-1);
    });
});