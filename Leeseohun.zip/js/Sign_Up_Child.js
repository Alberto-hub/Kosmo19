$(function () {
    $('#Nbtn').css('cursor','pointer');
    $('#Nbtn').click(function () {
        location.href = 'Sign_Up2.html';
    });
});