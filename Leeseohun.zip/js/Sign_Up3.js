$(function () {
    $('input').click(function () {
        location.href = 'Login_Main.html';
    });
});